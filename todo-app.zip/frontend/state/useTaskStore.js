
import create from 'zustand';

const useTaskStore = create((set) => ({
  tasks: [],
  fetchTasks: async () => {
    const res = await fetch('/api/tasks');
    const tasks = await res.json();
    set({ tasks });
  },
  addTask: async (task) => {
    await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(task),
    });
    set((state) => ({ tasks: [...state.tasks, task] }));
  },
  deleteTask: async (id) => {
    await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
    set((state) => ({ tasks: state.tasks.filter((task) => task.id !== id) }));
  },
}));
export default useTaskStore;
        