import axios from 'axios';

export default async function handler(req, res) {
  const { method } = req;

  if (method === 'GET') {
    const response = await axios.get('http://localhost:5000/api/tasks');
    res.status(200).json(response.data);
  }

  if (method === 'POST') {
    await axios.post('http://localhost:5000/api/tasks', req.body);
    res.status(201).json({ message: 'Task created' });
  }
}
