
import TaskList from '../components/TaskList';
import AddEditTask from '../components/AddEditTask';

export default function Home() {
  return (
    <div>
      <h1>To-Do List</h1>
      <AddEditTask />
      <TaskList />
    </div>
  );
}
        