
import useTaskStore from '../state/useTaskStore';
import { useState } from 'react';

const AddEditTask = () => {
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [recurrence, setRecurrence] = useState('');
  const { addTask } = useTaskStore();

  const handleSubmit = (e) => {
    e.preventDefault();
    addTask({ title, due_date: dueDate, recurrence });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Task title"
        required
      />
      <input
        type="date"
        value={dueDate}
        onChange={(e) => setDueDate(e.target.value)}
        required
      />
      <select value={recurrence} onChange={(e) => setRecurrence(e.target.value)}>
        <option value="">No Recurrence</option>
        <option value="daily">Daily</option>
        <option value="weekly">Weekly</option>
        <option value="monthly">Monthly</option>
      </select>
      <button type="submit">Add Task</button>
    </form>
  );
};

export default AddEditTask;
        