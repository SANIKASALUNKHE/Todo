
const TaskItem = ({ task }) => {
  const { deleteTask } = useTaskStore();

  return (
    <div className="task-item">
      <h3>{task.title}</h3>
      <p>Due: {task.due_date}</p>
      <p>Recurrence: {task.recurrence}</p>
      <button onClick={() => deleteTask(task.id)}>Delete</button>
    </div>
  );
};

export default TaskItem;
        