
const Task = require('../models/Task');

const taskController = {
  getTasks: async (req, res) => {
    const tasks = await Task.getAllTasks();
    res.json(tasks);
  },
  addTask: async (req, res) => {
    const newTask = req.body;
    await Task.addTask(newTask);
    res.status(201).json({ message: 'Task added' });
  },
  deleteTask: async (req, res) => {
    const taskId = req.params.id;
    await Task.deleteTask(taskId);
    res.status(200).json({ message: 'Task deleted' });
  },
};

module.exports = taskController;
        