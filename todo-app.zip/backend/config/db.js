
const { Pool } = require('pg');

// Database connection config
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'todo_db',
  password: 'password',
  port: 5432,
});

module.exports = pool;
        