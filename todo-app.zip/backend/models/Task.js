
const pool = require('../config/db');

const Task = {
  getAllTasks: async () => {
    const result = await pool.query('SELECT * FROM tasks');
    return result.rows;
  },
  addTask: async (task) => {
    const { title, due_date, recurrence } = task;
    await pool.query('INSERT INTO tasks (title, due_date, recurrence) VALUES ($1, $2, $3)', [title, due_date, recurrence]);
  },
  deleteTask: async (id) => {
    await pool.query('DELETE FROM tasks WHERE id = $1', [id]);
  },
};

module.exports = Task;
        